-- W-reMIX RESULT by Mr. Mary

-- Original W-MIX by Wisp

-- Clear lamp text taken from EC:TYPE-M by Ric
--[[ 
Hi!
I attempted to structure the code similar to how original .csv file was structured.
If you want to read through and make sense of the code, I suggest you open the result_L.csv file in another tab (preferably in a spreadsheet editor) and follow along.
Keep in mind that I have used LR2SkinConverter to initially upscale the original CSV files to 1080p.

I let myself have some creative liberties in places due to what Lua allows me to do when compared to LR2's primitive scripting.

Let's just say that writing this was a learning experience.
During the process I had to come over some issues:
	- multiple option states are duplicated
	- LR2 and beatoraja's implementation of Value elements doesn't match and it's not documented anywhere (or at least I couldn't find it)
	- you can only load LR2 fonts inside LR2 skins (they will not work with beatoraja skins, and there's no known way to convert between formats)
	- LR2 and beatoraja's point of origin (x = 0, y = 0) is placed in different places due to rendering backend differences (DirectX based LR2 starts in the top left corner and OpenGL based beatoraja starts in the bottom left corner)
	- duplicate source declarations had to be cherrypicked by hand

While I believe I have learned a lot during the process, I don't think I'm ever gonna attempt writing documentation. Once Lunatic Vibes (hopefully) kicks off for good, most people will go towards that and we'll be back to CSV skinning yet again.

For now, have an enjoy!
 ]]

local header = {
	type = 7,
	name = "W-reMIX RESULT",
	w = 1920,
	h = 1080,
	scene = 3600000,
	input = 500,
	fadeout = 2000,
	property = {
		{name = "Playside", def = "Left", item = {
			{name = "Left", op = 910},
			{name = "Right", op = 911},
		}},
		{name = "Show Table Level", def = "On", item = {
			{name = "On (titlebar corner)", op = 912},
			{name = "On (appended to title)", op = 913},
			{name = "Off", op = 914},
		}},
		{name = "Show Song Data", def = "On", item = {
			{name = "On", op = 915},
			{name = "Off", op = 916}
		}},
		{name = "Gauge Graph Color Scheme", def = "Default", item = {
			{name = "Default", op = 917},
			{name = "W-MIX-like", op = 918}
		}},
		{name = "Gauge Label", def = "Default (selected gauge)", item = {
			{name = "Default (selected gauge)", op = 919},
			{name = "Gauge Auto-Shift label", op = 920},
			{name = "Selected Lane option", op = 930}
		}},
		{name = "Enable Bilinear Filtering (for 1080p)", def = "On", item = {
			{name = "Off", op = 921},
			{name = "On", op = 922}
		}},
		{name = "Use Stagefile as background", def = "Off", item = {
			{name = "Off", op = 923},
			{name = "On (clears only)", op = 924},
			{name = "On (always)", op = 925}
		}},
		{name = "Stagefile box", def = "Stagefile", item = {
			{name = "Stagefile", op = 926},
			{name = "Timing and density graphs", op = 927}
		}},
		{name = "Misscount delta coloring", def = "Default (White for more)", item = {
			{name = "Default (white for more)", op = 928},
			{name = "Reverse (red for more)", op = 929}
		}},
		{name = "Density graph on top of the gauge graph", def = "Disabled", item = {
			{name = "Disabled", op = 931},
			{name = "Enabled", op = 932}
		}},
		{name = "Colored Fast/Slow count", def = "Disabled", item = {
			{name = "Disabled", op = 933},
			{name = "Enabled", op = 934}
		}},
		{name = "F/S ratio bar", def = "Disabled", item = {
			{name = "Disabled", op = 935},
			{name = "Enabled", op = 936}
		}},
		{name = "Total Combo Breaks", def = "Disabled", item = {
			{name = "Disabled", op = 937},
			{name = "Enabled", op = 938}
		}},
		{name = "Sound on Raise", def = "Disabled", item = {
			{name = "Disabled", op = 939},
			{name = "Score Raise", op = 940},
			{name = "Misscount Drop", op = 941},
			{name = "Score Raise or Misscount Drop", op = 942},
		}},
	},

	filepath = {
		{ name = "AAA", path = "IMAGE/AAA/*.png", def = "Random" },
		{ name = "AA", path = "IMAGE/AA/*.png", def = "Random" },
		{ name = "A", path = "IMAGE/A/*.png", def = "Random" },
		{ name = "CLEAR", path = "IMAGE/clear/*.png", def = "Random" },
		{ name = "FAILED", path = "IMAGE/fail/*.png", def = "Random" },
		{ name = "RANK", path = "system/djlevel/*.png", def = "perfect dark" },
		{ name = "Number", path = "system/number/*.png", def = "silver" },
	},
}

local function get_fs_color(type,channel)
	local chart_colors = {
		--fast
	{
		83,
		180,
		248
	},
	--slow
	{
		248,
		83,
		83
	}}

	value = chart_colors[type][channel]
	if skin_config.option["Colored Fast/Slow count"] == 933 then
		value = 255
	end
	return value
end

local function get_graph_option()
	option = "default"
	if skin_config.option["Gauge Graph Color Scheme"] == 917 then
		option = "wfix"
	end
	return option
end

local function get_filtering()
	option = 1 
	if skin_config.option["Enable Bilinear Filtering (for 1080p)"] == 921 then
		option = 0
	end
	return option
end

local function get_bp_color()
	option = "src_1172"
	if skin_config.option["Misscount delta coloring"] == 929 then
		option = "src_1172_reverse"
	end
	return option
end

local main_state = require("main_state")

-- you can use Lua to play custom sounds
-- the following code is ripped from simple-play by mnpyprrn

local luajava = require("luajava")
local gdx = luajava.bindClass("com.badlogic.gdx.Gdx")
local audio = nil

local sound = {

	init = function()
		pcall(function() audio = gdx.app:getApplicationListener():getAudioProcessor() end)
	end,

    play = function(path, vol)
		pcall(function() audio:play(path, vol) end)
	end,

	dispose = function(path)
		pcall(function() audio:dispose(path) end)
	end,

	stop = function(path)
		pcall(function() audio:stop(path) end)
	end
}
sound.init()


-- my attempt at checking if GAS is enabled

-- this reads the GAS state from the PlayerResource class
-- either I read from this class too fast, or the code I wrote is entirely wrong

--[[ local luajava = require("luajava")
local playerResource = luajava.newInstance("bms.player.beatoraja.PlayerConfig")

print(playerResource.getGaugeAutoShift()) ]]

--this successfully reads the GAS state from player1's config file
--downside - said file is updated on shutdown only

--[[ function isGASon()
	local i = 0
	for line in io.lines("player/player1/config.json") do
	  i = i + 1
	  if i == 34 then
		if string.match(line, "%d") ~= 0 then
			return true
		else return false
		end
	  end
	end
	return nil -- line not found
end ]]

local function diffPanelKeymodeSourceY()
	y = 0
	if main_state.option(160) or main_state.option(161) or main_state.option(164) or main_state.option(1160) then
		y = 493
	else
		if main_state.option(162) or main_state.option(163) or main_state.option(1161) then
			y = 464
		end
	end
	return y
end

local function isDoublePlay(playmode)
	playstyleAlpha = 0
	isDP = false
		if main_state.option(162) or main_state.option(163) or main_state.option(1161) then
			isDP = true
		end
	if playmode == "sp" then
		if isDP == false then playstyleAlpha = 255
		end
	end
	if playmode == "dp" then
		if isDP == true then playstyleAlpha = 255
		end
	end
	return playstyleAlpha
end

local function diffPanelDifficultySourceY()
	--start on unknown
	y = 664
	n = 0

	--search for diff
	repeat
		n = n + 1
	until main_state.option(150+n) or n == 5

	return y - (42 * n)
end

local function diffPanelLevelColor(color)
	n = 0

	diffColor = {
		{
			255,
			92,
			64,
			238,
			248,
			233
		},
		{
			255,
			211,
			118,
			205,
			67,
			69
		},
		{
			255,
			120,
			255,
			52,
			67,
			154
		}
	}

	repeat
		n = n + 1
	until main_state.option(150+n) or n == 5

	return diffColor[color][n+1]
end

local function infoPanelJudgeColor(color)
	n = 0

	judgeColor = {
		{
			203,
			255,
			85,
			85,
			69
		},
		{
			112,
			80,
			141,
			212,
			210
		},
		{
			189,
			80,
			224,
			105,
			108
		},
		{
			"VERY HARD",
			"HARD",
			"NORMAL",
			"EASY",
			"VERY EASY"
		}
	}

	repeat
		n = n + 1
	until main_state.option(180+n) or n == 4

	return judgeColor[color][n+1]
end

local function getBPM()
	minBPM = main_state.number(91)
	maxBPM = main_state.number(90)
	BPMstring = ""
	if minBPM ~= maxBPM then
		BPMstring = minBPM .. "-" .. maxBPM
	else BPMstring = minBPM
	end
	return BPMstring
end

local function getGrade(startOp)
	n = 0
	if main_state.option(startOp) then
		return 0
	end
	repeat 
		n = n + 1
	until main_state.option(startOp + n) or n == 7

	
	return n
end

local function appendTable()
	if skin_config.option["Show Table Level"] == 913 then
		return main_state.text(1002) .. " "
	else return ""
	end
end

local function get_fs_ratio_length(length, type)
	local totalfast = main_state.number(423)
	local totalslow = main_state.number(424)
	local totalnote = totalfast + totalslow

	local value = 0
	if type == 1 then
		value = length * (totalfast / totalnote)
	end
	if type == 2 then
		value = length * (totalslow / totalnote)
	end
	return value
end

local function getClear(num)
	if main_state.option(90) then
		return 0
	else if main_state.option(91) then
		return 1
	end
end
end
	
local shift_table = {
	src_x = {
	--	[420] = "dupa"
		[439] = -753,
		[562] = 385,
		[568] = 385,
		[574] = 385,
		[581] = 385, 
		[591] = 385,
	},
	src_y = {
		[439] = 287,
		[601] = -187,
		[608] = -187,
		[615] = -187,
		[622] = -187,
		[632] = -168,
		[896] = 42,
		[906] = 42,
		[916] = 42,

	},
	dst_x = {
		[434] = -1269,
		[441] = -1358,
		[448] = -1269,
		[456] = -1359,
		[464] = -1359,
		[476] = -1359,
		[498] = -1358,
		[546] = -1357,
		[557] = 1292,
		[564] = 3600,
		[565] = 1292,
		[570] = 3600,
		[571] = 1292,
		[576] = 3600,
		[577] = 1292,
		[583] = 3600,
		[584] = 1292,
		[593] = 1292,
		[603] = 1292,
		[610] = 1292,
		[617] = 1292,
		[624] = 1292,
		[634] = 1293,
		[643] = 1029,
		[659] = 1292,
		[725] = 1292,
		[732] = 1290,
		[739] = 1290,
		[764] = 1291,
		[790] = 1101,
		[898] = 1286,
		[908] = 1286,
		[918] = 1286,
		[931] = 1101,
		[938] = 1101,
		[945] = 1101,
		[957] = 1092,
		[1019] = 1092,
		[1083] = 1037,
		[1126] = 1038,
		[1137] = 1095,
		[1144] = 1095,
		[1154] = 1095,
		[1160] = 945,
		[1167] = 1095,
		[1174] = 945,
		[1181] = 930,
		[1188] = 945,
		[1194] = 1590,
		[1203] = 1590,
		[1209] = 1590,
		[1216] = 1027,
		[1223] = 1027,
		[1230] = 1027,
		[1237] = 1027,
		[1244] = 1027,
		[1251] = 1027,
		[1257] = 1027,
		[1264] = 1027,
		[1271] = 1552,
		[1277] = 1552,
		[1283] = 1553,
		[1305] = 1590,
		[1312] = 1590,
		[1319] = 1590,
		[1334] = 1292,
		[1339] = 1292,
		[1345] = 1292,
		[1351] = 1292,
		[1359] = 1292,
		[1360] = 1292,

		-- custom shit

		-- cb text and count
		[9000] = 1322,


	},
}

local function getShift(dimension, csvLine)
	if skin_config.option["Playside"] == 910 then
		return 0
	end
	if dimension == "src_x" then
		return shift_table.src_x[csvLine]
	end
	if dimension == "src_y" then
		return shift_table.src_y[csvLine]
	end
	if dimension == "dst_x" then
		return shift_table.dst_x[csvLine]
	end
end

local function raiseSoundPlayCheck()
	op = skin_config.option["Sound on Raise"]
	do_play = false
	score_diff = main_state.number(171) - main_state.number(170)
	bp_diff = main_state.number(177) - main_state.number(176)
	
	if op == 940 and score_diff > 0 then
		do_play = true
		print("case 1")
	end

	if op == 941 and bp_diff < 0 then
		do_play = true
		print("case 2")
	end

	if op == 942 and (score_diff > 0 or bp_diff < 0) then
		do_play = true
		print("case 3")
	end

	if main_state.number(170) == 0 then
		do_play = false
		print("first play")
	end

	return do_play
end

local function main()
    -- ヘッダ情報コピー
    local skin = {}
    for k, v in pairs(header) do
        skin[k] = v
    end

	-- sound stuff init, have to do it in the main function, otherwise game throws nul errors

--use this to track where we at in the loop
raise_sound_check = 0

local se = {
	path = skin_config.get_path("raise.ogg"),
	vol = main_state.volume_sys()
}

local function playRaiseSound()

	if raise_sound_check == 0 and raiseSoundPlayCheck() then
		sound.play(se.path, se.vol)
		raise_sound_check = 1
	end

	if raise_sound_check == 1 and not (main_state.timer(2) == main_state.timer_off_value) then
		-- we only stop the sound, disposing of it makes it get loaded on each result screen instance. instead we keep it in memory
		sound.stop(se.path)
		raise_sound_check = 2
		--print("dupa")
	end
end

	skin.source = {
		{id = 0, path = "system/main.png"},
		{id = 1, path = "IMAGE/AAA/*.png"},
		{id = 2, path = "IMAGE/AA/*.png"},
		{id = 3, path = "IMAGE/A/*.png"},
		{id = 4, path = "IMAGE/clear/*.png"},
		{id = 5, path = "IMAGE/fail/*.png"},
		{id = 6, path = "system/djlevel/*.png"},
		{id = 7, path = "system/BG_C.png"},
		{id = 8, path = "system/BG_F.png"},
		{id = 9, path = "system/CLEAR.png"},
		{id = 10, path = "system/number/*.png"},
		{id = 11, path = "system/gauge/*.png"},
		{id = "reMIX_gaugetype", path = "reMIXsystem/gaugetype.png"},
		{id = "src_reMIX_randomtype", path = "reMIXsystem/randomtype.png"},
		{id = "TypeM-cleartype", path = "reMIXsystem/cleartype.png"},
		{id = "reMIX_gauge_gas", path = "reMIXsystem/gauge_gas.png"},
		{id = "bp_number", path = "reMIXsystem/bp_number.png"},
		{id = "src_lanetext", path = "reMIXsystem/gaugegraph_text.png"},
		{id = "src_cb", path = "reMIXsystem/cb.png"},
		{id = "src_reMIX_randomtype_L", path = "reMIXsystem/randomtype-l.png"},
		{id = "src_reMIX_randomtype_R", path = "reMIXsystem/randomtype-r.png"},
		{id = "src_reMIX_randomtype_sep", path = "reMIXsystem/randomtype-separator.png"},
	}

	skin.font = {
		{id = 1, path = "reMIXfont/silver/font.fnt"},
		{id = 2, path = "reMIXfont/small/font.fnt"},
		{id = 3, path = "reMIXxirod/xirod.fnt"}
	}


	skin.image = {
		-- failed bg
		{id = "src_122", src = 8, x = 0, y = 0, w = 1280, h = 720},
		{id = "src_137", src = 8, y = 721, w = 349, h = 349},
		{id = "src_144", src = 8, x = 656, y = 721, w = 624, h = 624},
		{id = "src_152", src = 8, y = 1746, w = 1280, h = 158},
		{id = "src_162", src = 5, w = -1, h = -1},

		-- clear bg

		{id = "src_170", src = 7, x = 0, y = 0, w = 1280, h = 720},
		{id = "src_185", src = 7, y = 721, w = 349, h = 349},
		{id = "src_192", src = 7, x = 656, y = 721, w = 624, h = 624},
		{id = "src_201", src = 7, y = 1746, w = 1280, h = 158},
		{id = "src_211", src = 4, w = -1, h = -1},

		-- grade bg

		{id = "src_219", src = 3, w = -1, h = -1},
		{id = "src_229", src = 2, w = -1, h = -1},
		{id = "src_238", src = 1, w = -1, h = -1},
			
		-- stage result text

		{id = "src_246", src = 0, x = 393, y = 12, w = 341, h = 40},
		{id = "src_251", src = 0, x = 393, y = 56, w = 341, h = 40},

		-- difficulty

		{id = "src_275", src = 0, x = 385, y = 163, w = 290, h = 30},
		--merging multiple if args with a function call
		{id = "src_281", src = 0, x = 1304, y = diffPanelKeymodeSourceY(), w = 57, h = 22},
		{id = "src_338", src = 0, x = 1377, y = diffPanelDifficultySourceY(), w = 242, h = 41},

		-- song info

		{id = "src_432", src = 0, x = 1321, w = 376, h = 286},
		{id = "src_439", src = 0, x = 2070 + getShift("src_x",439), y = getShift("src_y",439), w = 317, h = 165},
		{id = "src_489", src = 0, x = 1170, y = 78, w = 13, h = 11},

		-- score box
		{id = "src_555", src = 0, y = 8, w = 360, h = 186},
		{id = "src_562", src = 0, x = getShift("src_x",562), y = 209, w = 360, h = 101},
		{id = "src_568", src = 0, x = getShift("src_x",568), y = 311, w = 360, h = 58},
		{id = "src_574", src = 0, x = getShift("src_x",574), y = 370, w = 360, h = 58},
		{id = "src_581", src = 0, x = getShift("src_x",581), y = 429, w = 360, h = 60},
		{id = "src_591", src = 0, x = getShift("src_x",591), y = 509, w = 360, h = 167},
		{id = "src_601", src = 0, x = 1704, y = 187 + getShift("src_y",601), w = 360, h = 67},
		{id = "src_608", src = 0, x = 1704, y = 256 + getShift("src_y",608), w = 360, h = 57},
		{id = "src_622", src = 0, x = 1704, y = 313 + getShift("src_y",622), w = 360, h = 61},
		{id = "src_632", src = 0, x = 1709, y = 554 + getShift("src_y",632), w = 351, h = 140},
		{id = "src_641", src = 0, x = 961, y = 118, w = 54, h = 33, divy = 3, cycle = 120},

		{id = "src_723", src = 0, x = 940, y = 189, w = 344, h = 24},
		{id = "reMIX_laneop", src = "src_lanetext", x = 0, y = 0, w = 344, h = 24},
		{id = "reMIX_gaugetype1", src = "reMIX_gaugetype", x = 0, y = 0, w = 121, h = 18},
		{id = "reMIX_gaugetype2", src = "reMIX_gaugetype", x = 0, y = 18, w = 121, h = 18},
		{id = "reMIX_gaugetype3", src = "reMIX_gaugetype", x = 0, y = 18 * 2, w = 121, h = 18},
		{id = "reMIX_gaugetype4", src = "reMIX_gaugetype", x = 0, y = 18 * 3, w = 121, h = 18},
		{id = "reMIX_gaugetype5", src = "reMIX_gaugetype", x = 0, y = 18 * 4, w = 121, h = 18},
		{id = "reMIX_gaugetype6", src = "reMIX_gaugetype", x = 0, y = 18 * 5, w = 121, h = 18},
		{id = "reMIX_gas", src = "reMIX_gauge_gas", x = 0, y = 0, w = 121, h = 18},
		{id = "reMIX_randomtype1", src = "src_reMIX_randomtype", x = 0, y = 0, w = 121, h = 18},
		{id = "reMIX_randomtype2", src = "src_reMIX_randomtype", x = 0, y = 18, w = 121, h = 18},
		{id = "reMIX_randomtype3", src = "src_reMIX_randomtype", x = 0, y = 18 * 2, w = 121, h = 18},
		{id = "reMIX_randomtype4", src = "src_reMIX_randomtype", x = 0, y = 18 * 3, w = 121, h = 18},
		{id = "reMIX_randomtype5", src = "src_reMIX_randomtype", x = 0, y = 18 * 4, w = 121, h = 18},
		{id = "reMIX_randomtype6", src = "src_reMIX_randomtype", x = 0, y = 18 * 5, w = 121, h = 18},
		{id = "reMIX_randomtype7", src = "src_reMIX_randomtype", x = 0, y = 18 * 6, w = 121, h = 18},
		{id = "reMIX_randomtype8", src = "src_reMIX_randomtype", x = 0, y = 18 * 7, w = 121, h = 18},
		{id = "reMIX_randomtype9", src = "src_reMIX_randomtype", x = 0, y = 18 * 8, w = 121, h = 18},
		{id = "reMIX_randomtype10", src = "src_reMIX_randomtype", x = 0, y = 18 * 9, w = 121, h = 18},

		{id = "reMIX_randomtype1_L", src = "src_reMIX_randomtype_L", x = 0, y = 0, w = 121, h = 18},
		{id = "reMIX_randomtype2_L", src = "src_reMIX_randomtype_L", x = 0, y = 18, w = 121, h = 18},
		{id = "reMIX_randomtype3_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 2, w = 121, h = 18},
		{id = "reMIX_randomtype4_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 3, w = 121, h = 18},
		{id = "reMIX_randomtype5_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 4, w = 121, h = 18},
		{id = "reMIX_randomtype6_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 5, w = 121, h = 18},
		{id = "reMIX_randomtype7_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 6, w = 121, h = 18},
		{id = "reMIX_randomtype8_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 7, w = 121, h = 18},
		{id = "reMIX_randomtype9_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 8, w = 121, h = 18},
		{id = "reMIX_randomtype10_L", src = "src_reMIX_randomtype_L", x = 0, y = 18 * 9, w = 121, h = 18},

		{id = "reMIX_randomtype1_R", src = "src_reMIX_randomtype_R", x = 0, y = 0, w = 121, h = 18},
		{id = "reMIX_randomtype2_R", src = "src_reMIX_randomtype_R", x = 0, y = 18, w = 121, h = 18},
		{id = "reMIX_randomtype3_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 2, w = 121, h = 18},
		{id = "reMIX_randomtype4_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 3, w = 121, h = 18},
		{id = "reMIX_randomtype5_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 4, w = 121, h = 18},
		{id = "reMIX_randomtype6_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 5, w = 121, h = 18},
		{id = "reMIX_randomtype7_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 6, w = 121, h = 18},
		{id = "reMIX_randomtype8_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 7, w = 121, h = 18},
		{id = "reMIX_randomtype9_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 8, w = 121, h = 18},
		{id = "reMIX_randomtype10_R", src = "src_reMIX_randomtype_R", x = 0, y = 18 * 9, w = 121, h = 18},

		{id = "reMIX_randomtype_sep", src = "src_reMIX_randomtype_sep", x = 0, y = 0, w = 4, h = 15},

		{id = "src_737", src = 0, x = 805, y = 131, w = 121, h = 18},
		{id = "current-clear", src = "TypeM-cleartype", x = 0, y = 0, w = 327, h = 209, divx = 3, divy = 11, cycle = 140, len = 11, ref = 370},
		{id = "best-clear", src = "TypeM-cleartype", x = 0, y = 0, w = 327, h = 209, divx = 3, divy = 11, cycle = 140, len = 11, ref = 371},
		{id = "src_788", src = 0, x = 1063, y = 115, w = 32, h = 69, divy = 3, cycle = 120},
		{id = "src_896", src = 0, x = 930, y = 576 + getShift("src_y",896), w = 364, h = 42},
		{id = "src_955", src = 0, x = 865, y = 214 + 21 * getGrade(320), w = 58, h = 21},
		{id = "src_1017", src = 0, x = 865, y = 214 + 21 * getGrade(340), w = 58, h = 21},
		{id = "src_1081", src = 0, x = 865, y = 193 + 21 * getGrade(300), w = 58, h = 21},

		{id = "src_1207", src = 0, x = 1155, y = 78, w = 7, h = 11},
		{id = "src_1262", src = 0, x = 1111, y = 78, w = 40, h = 11},
		{id = "src_1303", src = 0, x = 807, y = 552, w = 104, h = 11},

		{id = "src_1332", src = 6, x = 1, y = 1 + 129 * getGrade (300), w = 340, h = 128},
		{id = "src_1357", src = 6, x = 344, y = 1, w = 399, h = 399},

		-- clear fail anim

		{id = "src_1572", src = 7 + getClear(), y = 1746, w = 1280, h = 158},
		{id = "src_1583", src = 7 + getClear(), y = 1540, w = 1100, h = 176},
		{id = "src_1600", src = 7 + getClear(), y = 1125, w = 408, h = 408},

		{id = "cb_text", src = "src_cb", w = 22, h = 11},


	}

	skin.imageset = {
		{id = "src_730", ref = 40, images = {
			"reMIX_gaugetype1", "reMIX_gaugetype2", "reMIX_gaugetype3", "reMIX_gaugetype4", "reMIX_gaugetype5", "reMIX_gaugetype6"
		}},
		{id = "reMIX_randomtype", ref = 42, images = {
			"reMIX_randomtype1", "reMIX_randomtype2", "reMIX_randomtype3", "reMIX_randomtype4", "reMIX_randomtype5", "reMIX_randomtype6", "reMIX_randomtype7", "reMIX_randomtype8", "reMIX_randomtype9", "reMIX_randomtype10",
		}},
		{id = "reMIX_randomtype_L", ref = 42, images = {
			"reMIX_randomtype1_L", "reMIX_randomtype2_L", "reMIX_randomtype3_L", "reMIX_randomtype4_L", "reMIX_randomtype5_L", "reMIX_randomtype6_L", "reMIX_randomtype7_L", "reMIX_randomtype8_L", "reMIX_randomtype9_L", "reMIX_randomtype10_L",
		}},
		{id = "reMIX_randomtype_R", ref = 43, images = {
			"reMIX_randomtype1_R", "reMIX_randomtype2_R", "reMIX_randomtype3_R", "reMIX_randomtype4_R", "reMIX_randomtype5_R", "reMIX_randomtype6_R", "reMIX_randomtype7_R", "reMIX_randomtype8_R", "reMIX_randomtype9_R", "reMIX_randomtype10_R",
		}},
	}

	skin.text = {
		--bottom title
		{id = "src_266", font = 1, size = 50, align = 1, constantText = appendTable() .. main_state.text(12), overflow = 1},
		--side panel
			--title
		{id = "src_453", font = 2, size = 32, align = 2, ref = 10, overflow = 1},
			--artist
		{id = "src_461", font = 2, size = 32, align = 2, ref = 14, overflow = 1},
			--bpm
		{id = "src_476", font = 2, size = 32, align = 2, constantText = getBPM(), overflow = 1},
			--min+sec
		{id = "src_498", font = 2, size = 32, align = 2, constantText = string.format("%d:%02d", main_state.number(1163), main_state.number(1164))},
			--judgerank
		{id = "src_525", font = 2, size = 32, align = 2, constantText = infoPanelJudgeColor(4)},
			--table level
		{id = "src_1552", font = 1, ref = 1002, align = 2, size = 50, overflow = 1},
	}

	skin.value = {
		--number 45-49 is effectively the same thing in raja
		{id = "src_379", src = 0, x = 957, y = 57, w = 180, h = 13, divx = 10, digit = 2, ref = 45},
		{id = "src_762", src = 0, x = 1116, y = 154, w = 130, h = 15, divx = 10, digit = 3, ref = 107},
		{id = "src_1124", src = 0, x = 957, y = 36, w = 240, h = 34, divx = 12, divy = 2, ref = 154, digit = 5, zeropadding = 2},
		{id = "src_1135", src = 10, w = 220, h = 17, divx = 11, ref = 170, digit = 4},
		{id = "src_1142", src = 10, w = 220, h = 17, divx = 11, ref = 176, digit = 4},
		{id = "src_1152", src = 10, w = 220, h = 17, divx = 11, ref = 171, digit = 4},
		{id = "src_1158", src = 0, x = 957, y = 19, w = 240, h = 34, divx = 12, divy = 2, ref = 172, digit = 5, zeropadding = 2},
		{id = "src_1165", src = 10, w = 220, h = 17, divx = 11, ref = 177, digit = 4},
		{id = "src_1172", src = 0, x = 957, y = 19, w = 240, h = 34, divx = 12, divy = 2, ref = 178, digit = 5, zeropadding = 2},
		{id = "src_1172_reverse", src = "bp_number", x = 0, y = 0, w = 240, h = 34, divx = 12, divy = 2, ref = 178, digit = 5, zeropadding = 2},
		{id = "src_1179", src = 10, w = 220, h = 17, divx = 11, ref = 121, digit = 4},
		{id = "src_1186", src = 0, x = 957, y = 19, w = 240, h = 34, divx = 12, divy = 2, digit = 5, ref = 108, zeropadding = 2},
		{id = "src_1194", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 105, digit = 4},
		{id = "src_1201", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 106, digit = 4},
		{id = "src_1214", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 110, digit = 4},
		{id = "src_1221", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 111, digit = 4},
		{id = "src_1228", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 112, digit = 4},
		{id = "src_1235", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 113, digit = 4},
		{id = "src_1242", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 426, digit = 4},
		{id = "src_1249", src = 0, x = 970, y = 78, w = 120, h = 11, divx = 10, ref = 102, digit = 3},
		{id = "src_1255", src = 0, x = 970, y = 91, w = 132, h = 11, divx = 11, ref = 103, digit = 2},
		{id = "src_1269", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 179, digit = 5},
		{id = "src_1275", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 180, digit = 5},
		{id = "src_1310", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, digit = 4, ref = 423},
		{id = "src_1317", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, digit = 4, ref = 424, offset = {420} },
		{id = "total_cb", src = 0, x = 970, y = 78, w = 132, h = 11, divx = 11, ref = 425, digit = 4},
		
}

	skin.gaugegraph = {
		{id = "gauge-graph-wfix",
		--assist failed bg
		--assistClearBGColor = "09443c",

		--easy failed bg
		--assistAndEasyFailBGColor = "09443c",

		--normal failed bg
		grooveFailBGColor = "053d23",

		--hard bg
		grooveClearAndHardBGColor = "500200",

		--exhard bg
		exHardBGColor = "543500",

		--hazard bg
		hazardBGColor = "444444",

		--assist failed line
		--assistClearLineColor = "0078ff",

		--easy failed line
		--assistAndEasyFailLineColor = "0078ff",

		--groove failed line
		grooveFailLineColor = "00ff43",

		--hard line
		grooveClearAndHardLineColor = "ff2f2f",

		--exhard line
		exHardLineColor = "ffe349",

		--hazard line
		hazardLineColor = "cccccc",

		--assist+easy+groove clear line
		borderlineColor = "ff2f2f",

		--assist+easy+groove clear bg
		borderColor = "500200"
	},
	{id = "gauge-graph-default"},
	}

skin.timingdistributiongraph = {
	{id = "timinggraph"}
}

skin.judgegraph = {
	{id = "judgegraph", type = 1},
	{id = "judgegraph_gauge", backTexOff = 1},
	{id = "fsgraph", type = 2}
}

skin.bpmgraph = {
	{id = "bpmgraph"}
}

skin.customTimers = {
	{id = 10001, timer = function() return playRaiseSound() end}
}


skin.destination = {
	-- failed bg

	--dst 125
	{id = "src_122", op = {91}, loop = 200, blend = 1, filter = get_filtering(), dst = {
		{time = 0, w = 1920, h = 1080, blend = 1, a = 0},
		{time = 200, a = 255}
	}},
	--dst 130
	{id = "src_122", op = {91}, loop = 800, filter = get_filtering(), blend = 2, dst = {
		{time = 800, w = 1920, h = 1080, blend = 2, a = 0},
		{time = 2400, a = 100},
		{time = 4000, a = 0}
	}},
	--dst 140
	{id = "src_137", op = {91}, loop = 200, filter = 1, blend = 1, dst = {
		{time = 200, x = 694, y = 823, w = 524, h = -523, blend = 1, filter = get_filtering(), a = 155},
		{time = 10800, angle = -360}
	}},
	--dst 146
	{id = "src_144", op = {91}, loop = 200, filter = 1, blend = 1, dst = {
		{time = 200, x = 490, y = 1029, w = 936, h = -936, a = 55, blend = 1, filter = 1},
		{time = 15800, angle = 360}
	}},
	--dst 155
	{id = "src_152", op = {91}, loop = 200, filter = get_filtering(), blend = 2, dst = {
		{time = 200, x = 0, y = 0, w = 1920, h = -105, blend = 2, a = 155},
		{time = 4500, y = 492, h = -3, a = 0}
	}},
	--dst 164
	{id = "src_162", op = {91}, loop = 200, filter = 1, blend = 1, dst = {
		{time = 0, x = -960, y = -540, w = 3840, h = 2160, a = 0},
		{time = 200, x = 0, y = 0, w = 1920, h = 1080, a = 255}
	}},

	-- clear bg

	--dst 172
	{id = "src_170", op = {90}, loop = 200, blend = 1, filter = get_filtering(), dst = {
		{time = 0, w = 1920, h = 1080, blend = 1, a = 0},
		{time = 200, a = 255}
	}},
	--dst 178
	{id = "src_170", op = {90}, loop = 800, blend = 2, filter = get_filtering(), dst = {
		{time = 800, w = 1920, h = 1080, blend = 2, a = 0},
		{time = 2400, a = 100},
		{time = 4000, a = 0}
	}},
	--dst 187
	{id = "src_185", op = {90}, loop = 200, blend = 1, filter = 1, dst = {
		{time = 200, x = 694, y = 823, w = 524, h = -523, a = 155},
		{time = 10800, angle = -360}
	}},
	--dst 194
	{id = "src_192", op = {90}, loop = 200, blend = 1, filter = 1, dst = {
		{time = 200, x = 490, y = 1029, w = 936, h = -936, a = 55, blend = 1, filter = 1},
		{time = 15800, angle = 360}
	}},
	--dst 203
	{id = "src_201", op = {90}, loop = 200, blend = 2, filter = get_filtering(), dst = {
		{time = 200, x = 0, y = 0, w = 1920, h = -105, blend = 2, a = 155},
		{time = 4500, y = 492, h = -3, a = 0}
	}},
	--dst 213
	{id = "src_211", op = {90}, loop = 200, blend = 1, filter = 1, dst = {
		{time = 0, x = -960, y = -540, w = 3840, h = 2160, a = 0},
		{time = 200, x = 0, y = 0, w = 1920, h = 1080, a = 255}
	}},

	-- grade bg

	--dst 221
	{id = "src_219", op = {90, 302}, loop = 200, blend = 1, filter = 1, dst = {
		{time = 0, x = -960, y = -540, w = 3840, h = 2160, a = 0},
		{time = 200, x = 0, y = 0, w = 1920, h = 1080, a = 255}
	}},
	--dst 231
	{id = "src_229", op = {90, 301}, loop = 200, blend = 1, filter = 1, dst = {
		{time = 0, x = -960, y = -540, w = 3840, h = 2160, a = 0},
		{time = 200, x = 0, y = 0, w = 1920, h = 1080, a = 255}
	}},
	--dst 240
	{id = "src_238", op = {90, 300}, loop = 200, blend = 1, filter = 1, dst = {
		{time = 0, x = -960, y = -540, w = 3840, h = 2160, a = 0},
		{time = 200, x = 0, y = 0, w = 1920, h = 1080, a = 255}
	}},
	-- stagefile bg
	{ id = -100, loop = 200, blend = 1, filter = 1, draw = function() return skin_config.option["Use Stagefile as background"] ~= 923 and (main_state.option(90) or (main_state.option(91) and skin_config.option["Use Stagefile as background"] == 925)) end, dst = {
		{time = 0, x = -960, y = -540, w = 3840, h = 2160, a = 0},
		{time = 200, x = 0, y = 0, w = 1920, h = 1080, a = 255}
	}},

	-- stage result text

	--dst 248
	{id = "src_246", filter = get_filtering(), op = {90}, dst = {
		{time = 0, x = 703, y = 1016, w = 512, h = 60, acc = 2}
	}},
	--dst 253
	{id = "src_251", filter = get_filtering(), op = {91}, dst = {
		{time = 0, x = 703, y = 1016, w = 512, h = 60, acc = 2}
	}},

	-- title bar

	--dst 262
	{id = -110, dst = {
		{time = 0, x = 0, y = 0, w = 1920, h = 53}
	}},
	--dst 268
	{id = "src_266", filter = 1, loop = 600, dst = {
		{time = 500, x = 960, y = 0, w = 1800, h = 50, a = 0},
		{time = 600, a = 255}
	}},

	-- difficulty
	--dst 277
	{id = "src_275", acc = 2, blend = 1, filter = get_filtering(), dst = {
		{time = 0, x = 744, y = 68, w = 435, h = 45}
	}},
	--dst 284
	{id = "src_281", blend = 1, loop = 500, filter = get_filtering(), dst = {
		{time = 200, x = 751, y = 74, w = 86, h = 33, acc = 2, a = 0},
		{time = 500, a = 255},
		{time = 2000, a = 155},
		{time = 3500, a = 255}
	}},
	--dst 372
	{id = "src_338", blend = 1, filter = get_filtering(), acc = 2, loop = 500, dst = {
		{time = 200, x = 822, y = 60, w = 363, h = 62, a = 0},
		{time = 500, a = 255},
		{time = 2000, a = 155},
		{time = 3500, a = 255}
	}},
	--dst 381
	{id = "src_379", blend = 1, loop = 500, filter = get_filtering(), dst = {
		{time = 200, x = 1099, y = 80, w = 27, h = 19, a = 30, r = diffPanelLevelColor(1), g = diffPanelLevelColor(2), b = diffPanelLevelColor(3)},
		{time = 500, a = 255},
		{time = 2000, a = 135},
		{time = 3500, a = 255}
	}},

	-- song info

	--dst 434
	{id = "src_432", op = {915}, blend = 1, loop = 500, filter = get_filtering(), dst = {
		{time = 100, x = 1312 + getShift("dst_x",434), y = 671, w = 564, h = 0, acc = 2},
		{time = 500, y = 455, h = 429, a = 255}
	}},
	--dst 441
	{id = "src_439", op = {915}, blend = 1, loop = 700, filter = get_filtering(), dst = {
		{time = 300, x = 1401 + getShift("dst_x",441), y = -304, w = 475, h = 750, acc = 2, a = 0},
		{time = 700, y = 198, h = 248, a = 255}
	}},
	--dst 448 stagefile
	{id = -100, op = {915, 926}, loop = 900, filter = 1, dst = {
		{time = 500, x = 1324 + getShift("dst_x",448), y = 674, w = 540, h = 1, a = 0, acc = 2},
		{time = 900, y = 467, h = 405, a = 255}
	}},

	-- dupa cycki
	{id = "fsgraph", op = {915, 927}, loop = 900, dst = {
		{time = 500, x = 1324 + getShift("dst_x",448), y = 674, w = 540, h = 1, a = 0, acc = 2},
		{time = 900, y = 602, h = 135, a = 255}
	}},
	{id = "judgegraph", op = {915, 927}, loop = 900, dst = {
		{time = 500, x = 1324 + getShift("dst_x",448), y = 674, w = 540, h = 1, a = 0, acc = 2},
		{time = 900, y = 737, h = 135, a = 255}
	}},
	{id = "timinggraph", op = {915, 927}, loop = 900, dst = {
		{time = 500, x = 1864 + getShift("dst_x",448), y = 674, w = -540, h = 1, a = 0, acc = 2},
		{time = 900, y = 467, h = 135, a = 255}
	}},

	--dst 455
	{id = "src_453", op = {915}, blend = 1, filter = 1, loop = 900, dst = {
		{time = 700, x = 1846 + getShift("dst_x",456), y = 376, w = 340, h = 18, a = 0},
		{time = 900, a = 255}
	}},
	--dst 463
	{id = "src_461", op = {915}, blend = 1, filter = 1, loop = 900, dst = {
		{time = 700, x = 1846 + getShift("dst_x",464), y = 342, w = 310, h = 18, a = 0},
		{time = 900, a = 255}
	}},
	--dst 478
	{id = "src_476", op = {915}, blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 1846 + getShift("dst_x",476), y = 306, w = 195, h = 18, a = 0},
		{time = 900, a = 255}
	}},
	-- bpm dash
--[[ 	--dst 491
	{id = "src_489", blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 1765, y = 294, w = 20, h = 17, a = 30},
		{time = 900, a = 255}
	}} ]]
	--dst 500
	{id = "src_498", op = {915}, blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 1846 + getShift("dst_x",498), y = 271, w = 195, h = 18, a = 30},
		{time = 900, a = 255}
	}},
	--dst 546
	{id = "src_525", op = {915}, blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 1846 + getShift("dst_x",546), y = 236, w = 195, h = 18, a = 0, r = infoPanelJudgeColor(1), g = infoPanelJudgeColor(2), b = infoPanelJudgeColor(3)},
		{time = 900, a = 255}
	}},

	-- score box

	--dst 557
	{id = "src_555", blend = 1, filter = get_filtering(), loop = 400, dst = {
		{time = 0, x = 43 + getShift("dst_x",557), y = 900, w = 540, h = 0, acc = 2, a = 0},
		{time = 400, y = 756, h = 279, a = 255}
	}},
	--dst 564
	{id = "src_562", blend = 1, filter = get_filtering(), loop = 400, dst = {
		{time = 0, x = -1200 + getShift("dst_x",564), y = 596, w = 540, h = 151, acc = 2, a = 0},
		{time = 400, x = 43 + getShift("dst_x",565), a = 255}
	}},
	--dst 570
	{id = "src_568", blend = 1, filter = get_filtering(), loop = 500, dst = {
		{time = 100, x = -1200 + getShift("dst_x",570), y = 507, w = 540, h = 87, acc = 2, a = 0},
		{time = 500, x = 43 + getShift("dst_x",571), a = 255}
	}},
	--dst 576
	{id = "src_574", blend = 1, filter = get_filtering(), loop = 600, dst = {
		{time = 200, x = -1200 + getShift("dst_x",576), y = 419, w = 540, h = 87, acc = 2, a = 0},
		{time = 600, x = 43 + getShift("dst_x",577), a = 255}
	}},
	--dst 583
	{id = "src_581", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 300, x = -1200 + getShift("dst_x",583), y = 327, w = 540, h = 90, acc = 2, a = 0},
		{time = 700, x = 43 + getShift("dst_x",584), a = 255}
	}},
	--dst 593
	{id = "src_591", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 300, x = 43 + getShift("dst_x",593), y = -765, w = 540, h = 750, acc = 2, a = 0},
		{time = 700, y = 74, h = 250, a = 255}
	}},
	--dst 603
	{id = "src_601", blend = 2, filter = get_filtering(), loop = 1000, dst = {
		{time = 1000, x = 43 + getShift("dst_x",603), y = 596, w = 540, h = 100, acc = 2, a = 0, r = 0},
		{time = 1400, a = 155, r = 256},
		{time = 1800, a = 0},
		{time = 4500, a = 0}
	}},
	--dst 610
	{id = "src_608", blend = 2, filter = get_filtering(), loop = 1100, dst = {
		{time = 1100, x = 43 + getShift("dst_x",610), y = 506, w = 540, h = 85, acc = 2, a = 0, r = 0},
		{time = 1500, a = 155, r = 256},
		{time = 1900, a = 0},
		{time = 4600, a = 0}
	}},
	--dst 617
	{id = "src_608", blend = 2, filter = get_filtering(), loop = 1200, dst = {
		{time = 1200, x = 43 + getShift("dst_x",617), y = 417, w = 540, h = 86, acc = 2, a = 0, r = 0},
		{time = 1600, a = 155, r = 256},
		{time = 2000, a = 0},
		{time = 4700, a = 0}
	}},
	--dst 624
	{id = "src_622", blend = 2, filter = get_filtering(), loop = 1300, dst = {
		{time = 1300, x = 43 + getShift("dst_x",624), y = 326, w = 540, h = 91, acc = 2, a = 0, r = 0},
		{time = 1700, a = 155, r = 256},
		{time = 2100, a = 0},
		{time = 4800, a = 0}
	}},
	--dst 634
	{id = "src_632", blend = 2, filter = get_filtering(), loop = 100, dst = {
		{time = 1000, x = 51 + getShift("dst_x",634), y = 78, w = 526, h = 210, acc = 2, a = 0, r = 0},
		{time = 2000, a = 100},
		{time = 3000, a = 0}
	}},
	--dst 643
	{id = "src_641", blend = 1, filter = get_filtering(), loop = 740, dst = {
		{time = 700, x = 351 + getShift("dst_x",643), y = 254, w = 81, h = 16, acc = 2, a = 0},
		{time = 740, a = 255},
		{time = 780, a = 255}
	}},
	--dst 659
	{id = "gauge-graph-" .. get_graph_option(), loop = 700, blend = 2, filter = 1, dst = {
		{time = 300, x = 55 + getShift("dst_x",659), y = 915, w = 516, h = 0, acc = 2, a = 0},
		{time = 700, y = 767, h = 256, a = 256}
	}},
	{id = "judgegraph_gauge", loop = 700, op = {932}, blend = 2, filter = 1, dst = {
		{time = 300, x = 55 + getShift("dst_x",659), y = 915, w = 516, h = 0, acc = 2, a = 0},
		{time = 700, y = 767, h = 256, a = 63}
	}},
	--dst 725
	{id = "src_723", blend = 1, draw = function() return (skin_config.option["Gauge Label"] ~= 930) or main_state.option(290) end, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 55 + getShift("dst_x",725), y = 774, w = 516, h = 36, acc = 2, a = 0},
		{time = 1000, a = 255}
	}},
	--dst 732
	{id = "src_730", op = {-290, 919}, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 259 + getShift("dst_x",732), y = 779, w = 182, h = 27, a = 0},
		{time = 1000, a = 255}
	}},
	--gas marker
	{id = "reMIX_gas", draw = function() return (skin_config.option["Gauge Label"] == 920) and not main_state.option(290) end, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 259 + getShift("dst_x",732), y = 779, w = 182, h = 27, a = 0},
		{time = 1000, a = 255}
	}},
	--text for the random marker
	{id = "reMIX_laneop", blend = 1, draw = function() return (skin_config.option["Gauge Label"] == 930) and not main_state.option(290) end, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 55 + getShift("dst_x",725), y = 774, w = 516, h = 36, acc = 2, a = 0},
		{time = 1000, a = 255}
	}},
	--random marker
	{id = "reMIX_randomtype", op = {-290, 930}, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 259 + getShift("dst_x",732), y = 779, w = 182, h = 27, a = 0},
		{time = 1000, a = isDoublePlay("sp")}
	}},
--[[ 	
	[00:04]Koky: Is there a version of wmix result that displays dp lane options
	[00:08]rai: once he makes one
	[00:09]Koky: :yumyum: 
]]
	{id = "reMIX_randomtype_L", op = {-290, 930}, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 239 + getShift("dst_x",732), y = 779, w = 182, h = 27, a = 0},
		{time = 1000, a = isDoublePlay("dp")}
	}},
	{id = "reMIX_randomtype_R", op = {-290, 930}, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 259 + getShift("dst_x",732), y = 779, w = 182, h = 27, a = 0},
		{time = 1000, a = isDoublePlay("dp")}
	}},
	{id = "reMIX_randomtype_sep", op = {-290, 930}, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 337 + getShift("dst_x",732), y = 780, w = 6, h = 22, a = 0},
		{time = 1000, a = isDoublePlay("dp")}
	}},
	--dst 739
	{id = "src_737", op = {290}, filter = get_filtering(), loop = 1000, dst = {
		{time = 800, x = 259 + getShift("dst_x",739), y = 779, w = 182, h = 27, a = 0},
		{time = 1000, a = 255}
	}},
	--dst 764
	{id = "src_762", filter = get_filtering(), loop = 1100, dst = {
		{time = 1000, x = 468 + getShift("dst_x",764), y = 780, w = 19, h = 23, a = 0},
		{time = 1100, a = 255}
	}},
	--dst 841
	{id = "current-clear", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 435 + getShift("dst_x",790), y = 701, w = 123, h = 24, a = 0},
		{time = 700, a = 255}
	}},
	{id = "best-clear", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 265 + getShift("dst_x",790), y = 701, w = 123, h = 24, a = 0},
		{time = 700, a = 255}
	}},
	--dst 790
	{id = "src_788", blend = 1, filter = get_filtering(), loop = 740, dst = {
		{time = 700, x = 384 + getShift("dst_x",790), y = 693, w = 48, h = 35, acc = 2, a = 0},
		{time = 740, a = 255},
		{time = 780, a = 255}
	}},
	-- clear lamp update
	{id = "src_896", blend = 1, filter = 1, loop = 700, draw = function()
		local BESTCLEAR = main_state.number(371)
		local CURRENTCLEAR = main_state.number(370)
		return BESTCLEAR < CURRENTCLEAR and CURRENTCLEAR >= 2
	end, dst = {
		{time = 700, x = 43 + getShift("dst_x",898), y = 680, w = 546, h = 63, a = 225},
		{time = 750, a = 120},
		{time = 800, a = 225}
	}},
	-- dst 898
	{id = "src_896", op = {335}, blend = 1, filter = 1, loop = 700, dst = {
		{time = 700, x = 43 + getShift("dst_x",898), y = 626, w = 546, h = 63, a = 225},
		{time = 750, a = 120},
		{time = 800, a = 225}
	}},
	--dst 908
	{id = "src_896", op = {330}, blend = 1, filter = 1, loop = 700, dst = {
		{time = 700, x = 43 + getShift("dst_x",908), y = 537, w = 546, h = 63, a = 225},
		{time = 750, a = 120},
		{time = 800, a = 225}
	}},
	--dst 918
	{id = "src_896", op = {332}, blend = 1, filter = 1, loop = 700, dst = {
		{time = 700, x = 43 + getShift("dst_x",918), y = 449, w = 546, h = 63, a = 225},
		{time = 750, a = 120},
		{time = 800, a = 225}
	}},
	--dst 931
	{id = "src_788", blend = 1, filter = get_filtering(), loop = 740, dst = {
		{time = 700, x = 384 + getShift("dst_x",931), y = 641, w = 48, h = 34, acc = 2, a = 0},
		{time = 740, a = 255},
		{time = 780, a = 255}
	}},
	--dst 938
	{id = "src_788", blend = 1, filter = get_filtering(), loop = 740, dst = {
		{time = 700, x = 384 + getShift("dst_x",938), y = 551, w = 48, h = 34, acc = 2, a = 0},
		{time = 740, a = 255},
		{time = 780, a = 255}
	}},
	--dst 945
	{id = "src_788", blend = 1, filter = get_filtering(), loop = 740, dst = {
		{time = 700, x = 384 + getShift("dst_x",945), y = 462, w = 48, h = 35, acc = 2, a = 0},
		{time = 740, a = 255},
		{time = 780, a = 255}
	}},
	--dst 957
	{id = "src_955", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 288 + getShift("dst_x",957), y = 642, w = 87, h = 32, a = 0},
		{time = 700, a = 255}
	}},
	--dst 1019
	{id = "src_1017", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 457 + getShift("dst_x",1019), y = 642, w = 87, h = 32, a = 0},
		{time = 700, a = 255}
	}},

	-- FIX THIS SHIT, LIKE THIS IS THE REASON WHY YOURE DOING THE THING YOURE DOING

	--dst 1083
	{id = "src_1081", blend = 1, filter = 1, loop = 800, dst = {
		{time = 800, x = 319 + getShift("dst_x",1083), y = 600, w = 87, h = 32}
	}},
	--dst 1126
	{id = "src_1124", blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 412 + getShift("dst_x",1126), y = 603, w = 30, h = 26, a = 0},
		{time = 900, a = 255}
	}},

	--dst 1137
	{id = "src_1135", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 270 + getShift("dst_x",1137), y = 557, w = 30, h = 25, a = 30},
		{time = 700, a = 255}
	}},
	--dst 1144
	{id = "src_1142", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 270 + getShift("dst_x",1144), y = 468, w = 30, h = 26, a = 30},
		{time = 700, a = 255}
	}},
	--dst 1154
	{id = "src_1152", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 435 + getShift("dst_x",1154), y = 557, w = 30, h = 25, a = 30},
		{time = 700, a = 255}
	}},
	--dst 1160
	{id = "src_1158", blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 412 + getShift("dst_x",1160), y = 515, w = 30, h = 26, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1167
	{id = "src_1165", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 435 + getShift("dst_x",1167), y = 468, w = 30, h = 26, a = 30},
		{time = 700, a = 255}
	}},
	--dst 1174
	{id = get_bp_color(), blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 412 + getShift("dst_x",1174), y = 426, w = 30, h = 26, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1181
	{id = "src_1179", blend = 1, filter = get_filtering(), loop = 700, dst = {
		{time = 500, x = 435 + getShift("dst_x",1181), y = 380, w = 30, h = 25, a = 30},
		{time = 700, a = 255}
	}},
	--dst 1188
	{id = "src_1186", blend = 1, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 412 + getShift("dst_x",1188), y = 338, w = 30, h = 25, a = 0},
		{time = 900, a = 255}
	}},
	-- dst 1196
	{id = "src_1194", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 87 + getShift("dst_x",1194), y = 156, w = 18, h = 17, a = 0},
		{time = 900, a = 255}
	}},
	-- dst 1203
	{id = "src_1201", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 177 + getShift("dst_x",1203), y = 156, w = 18, h = 17, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1209
	{id = "src_1207", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 163 + getShift("dst_x",1209), y = 156, w = 11, h = 17, a = 0},
		{time = 900, a = 255}
	}},
	-- cb count
	{id = "cb_text", op = {938}, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 280 + getShift("dst_x",9000), y = 185, w = 33, h = 16, a = 0},
		{time = 900, a = 227}
	}},
	{id = "total_cb", op = {938}, filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 262 + getShift("dst_x",9000), y = 156, w = 18, h = 17, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1216
	{id = "src_1214", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 462 + getShift("dst_x",1216), y = 254, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1223
	{id = "src_1221", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 462 + getShift("dst_x",1223), y = 224, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1230
	{id = "src_1228", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 462 + getShift("dst_x",1230), y = 194, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1237
	{id = "src_1235", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 462 + getShift("dst_x",1237), y = 164, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1244
	{id = "src_1242", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 462 + getShift("dst_x",1244), y = 134, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1251
	{id = "src_1249", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 435 + getShift("dst_x",1251), y = 98, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1257
	{id = "src_1255", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 498 + getShift("dst_x",1257), y = 98, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1264
	{id = "src_1262", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 492 + getShift("dst_x",1264), y = 98, w = 60, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1271
	{id = "src_1269", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 87 + getShift("dst_x",1271), y = 98, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1277
	{id = "src_1275", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 195 + getShift("dst_x",1277), y = 98, w = 18, h = 16, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1283
	{id = "src_1207", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 181 + getShift("dst_x",1283), y = 98, w = 11, h = 17, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1305
	{id = "src_1303", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 93 + getShift("dst_x",1305), y = 243, w = 156, h = 17, a = 0},
		{time = 900, a = 255}
	}},
	-- ratio bar
	{id = -111, loop = 900, op = {936}, dst = {
		{time = 700, x = 87 + getShift("dst_x",1312), y = 216, w = get_fs_ratio_length(162,1), h = 17, a = 0, r = 0, g = 0, b = 255},
		{time = 900, a = 63}
	}},
	{id = -111, loop = 900, op = {936}, dst = {
		{time = 700, x = 87 + getShift("dst_x",1312) + get_fs_ratio_length(162,1), y = 216, w = get_fs_ratio_length(162,2), h = 17, a = 0, r = 255, g = 0, b = 0},
		{time = 900, a = 63}
	}},
	--dst 1312
	{id = "src_1310", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 87 + getShift("dst_x",1312), y = 216, w = 18, h = 17, a = 0, r = get_fs_color(1,1), g = get_fs_color(1,2), b = get_fs_color(1,3)},
		{time = 900, a = 255}
	}},
	--dst 1319
	{id = "src_1317", filter = get_filtering(), loop = 900, dst = {
		{time = 700, x = 177 + getShift("dst_x",1319), y = 216, w = 18, h = 17, a = 0, r = get_fs_color(2,1), g = get_fs_color(2,2), b = get_fs_color(2,3)},
		{time = 900, a = 255}
	}},
	--dst 1334
	{id = "src_1332", blend = 1, filter = get_filtering(), timer = 151, loop = 500, dst = {
		{time = 250, x = 61 + getShift("dst_x",1334), y = -420, w = 510, h = 1950, acc = 1, a = 0},
		{time = 500, y = 807, h = 192, a = 125}
	}},
	--dst 1339
	{id = "src_1332", blend = 1, filter = get_filtering(), timer = 151, loop = 600, dst = {
		{time = 400, x = 61 + getShift("dst_x",1339), y = 180, w = 510, h = 1350, acc = 1, a = 0},
		{time = 600, y = 807, h = 192, a = 255}
	}},
	--dst 1345
	{id = "src_1332", blend = 2, timer = 151, loop = 900, filter = get_filtering(), dst = {
		{time = 500, x = 61 + getShift("dst_x",1345), y = 807, w = 510, h = 192, acc = 2, a = 0},
		{time = 700, a = 95},
		{time = 900, a = 0}
	}},
	--dst 1351
	{id = "src_1332", blend = 2, filter = get_filtering(), loop = 900, timer = 151, dst = {
		{time = 900, x = 61 + getShift("dst_x",1351), y = 807, w = 510, h = 192, acc = 2, a = 0},
		{time = 1900, a = 95},
		{time = 2900, a = 0}
	}},
	--dst 1359
	{id = "src_1357", blend = 2, filter = 1, timer = 151, loop = -1, op = {300}, dst = {
		{time = 700, x = 310 + getShift("dst_x",1359), y = 869, w = 0, h = 0, acc = 2, a = 0, center = 5},
		{time = 900, x = 16 + getShift("dst_x",1360), y = 587, w = 599, h = 598, a = 220},
		{time = 1800, a = 0}
	}},
	--dst 1554
	{id = "src_1552", blend = 1, filter = get_filtering(), op = {912}, loop = 900, dst = {
		{time = 700, x = 1870, y = 0, w = 600, h = 50, a = 0},
		{time = 900, a = 255}
	}},
	--dst 1574
	{id = "src_1572", blend = 2, filter = get_filtering(), loop = -1, dst = {
		{time = 700, y = 428, w = 1920, h = 237, a = 0},
		{time = 900, y = 542, w = 1920, h = 3, a = 255},
		{time = 1000, a = 0}
	}},
	--dst 1585
	{id = "src_1583", filter = get_filtering(), loop = -1, dst = {
		{time = 0, x = 142, y = -792, w = 1650, h = 2109, a = 0},
		{time = 200, y = 408, h = 264, a = 255},
		{time = 700},
		{time = 800, y = 534, h = 0, a = 0}
	}},
	--dst 1594
	{id = "src_1583", blend = 2, loop = -1, filter = get_filtering(), dst = {
		{time = 300, x = 142, y = 408, w = 1650, h = 264, a = 0},
		{time = 400, a = 255},
		{time = 500, a = 0}
	}},
	--dst 1602
	{id = "src_1600", blend = 2, filter = get_filtering(), loop = -1, dst = {
		{time = 0, x = 627, y = 231, w = 612, h = 612, a = 255},
		{time = 350, x = -600, y = -975, w = 3120, h = 3120, a = 0}
	}},
	--dst 1721
	{id = -110, blend = 1, loop = 1500, timer = 2, dst = {
		{time = 0, y = 1080, w = 1920, h = 1080, acc = 1, a = 122},
		{time = 500, y = 540, a = 255},
		{time = 1500, y = 0, acc = 0}
	}},
	--dst 1727
	{id = -110, blend = 1, loop = 1500, timer = 2, dst = {
		{time = 0, y = -1080, w = 1920, h = 1080, acc = 1, a = 122},
		{time = 500, y = -540, a = 255},
		{time = 1500, y = 0, acc = 0}
	}},
}

-- i made an attempt at writing a scorecard thing, this is the remnants

--[[ local stringDump = function(num)
	return main_state.text(num) .. "\n"
end

local intDump = function(num)
	return main_state.number(num) .. "\n"
end

local dumpFile = io.open("dupa.lua", "w")
dumpFile:write(stringDump(2) .. stringDump(12) .. stringDump(16) .. stringDump(1001) .. stringDump(1002) .. intDump(21))
dumpFile:close()
]]

	return skin
end




return {
    header = header,
    main = main
}