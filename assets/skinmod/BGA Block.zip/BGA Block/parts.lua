local parts = {}

-- param g : geometry
local function load(g)
	
	local blockw = 360 -- block width
	local blockh = 1080 -- block height
	local blockx = 0 
	local blocky = 0  -- these two define the bottom left corner
	

	parts.destination = {
		{id = "bga", dst = {
			{x = blockx, y = blocky, w = blockw, h = blockh / 3, a = 255}
			}},
		{id = "bga", dst = {
			{x = blockx, y = blocky + blockh / 3, w = blockw, h = blockh / 3, a = 255}
			}},
		{id = "bga", dst = {
			{x = blockx, y = blocky + 2 *(blockh / 3), w = blockw, h = blockh / 3, a = 255}
			}},
	}
	
	return parts	
	
end

return {
	parts = parts,
	load = load
}