return {
	-- 切り抜き範囲の指定
	BOMB_X = 0,
	BOMB_Y = 2,
	BOMB_WIDTH = 640,
	BOMB_HEIGHT = 648,
	-- 分割数
	BOMB_DIVX = 4,
	BOMB_DIVY = 4,
	-- アニメーション再生周期
	BOMB_ANIMATION_CYCLE = 250,
	-- 表示サイズ
	BOMB_MAGNIFICATION = 2
}
