-- Ribbons extension for simple-play
-- coded by Mr. Mary (@zlewyjuzjado)
-- respect to @mnpyprrn

-- This is an addon which adds "ribbons" showing current play modifiers

-- Supported modifiers:
	-- Lane modifier (random, mirror etc)
	-- Gauge modifier (Assist to Hazard + GAS)
	-- Difficulty
	-- Autoplay/replay status
	-- Longnote mode (if LNs are present)
	
-- By default the ribbons are located in the bottom left part of the screen
-- If you wish to move the ribbons, comment out the current line of "local ribbon" and uncomment the one you wish to use!

local parts = {}

-- param g : geometry
local function load(g)


local function get_diff()
    curr_diff = 6
    repeat
        curr_diff = curr_diff - 1
    until main_state.option(150 + curr_diff)
    return curr_diff
end

local function get_play()
	curr_play = "blank"
	if main_state.option(33) then
		curr_play = "play_1"
	elseif main_state.option(84) then
		curr_play = "play_2"
	elseif main_state.option(1080) then
		curr_play = "play_3"
	end
	return curr_play
end

-- local function get_stage()
	-- curr_stage = 0
	-- repeat
		-- curr_stage = curr_stage + 1
	-- until main_state.option(279 + curr_stage)
	-- return curr_stage
-- end

	
-- uncomment correct line for where you want the ribbons

	--	left side
	local ribbon = {x = 0, y = 0, w = 200, h = 40}
	
	--	right side	
	-- local ribbon = {x = 1120, y = 0, w = 200, h = 40}
	
	-- bottom of bga
	-- local ribbon = {x = g.bga_x, y = g.bga_y, w = g.bga_width / 4, h = g.bga_width / 20}
	
	-- top of bga
	-- local ribbon = {x = g.bga_x, y = g.bga_y + g.bga_height - g.bga_height / 20, w = g.bga_width / 4, h = g.bga_width / 20}
	
	-- top of lane
	--local ribbon = {x = g.lane_origin_x, y = 1080 - g.lanes_width / 20, w = g.lanes_width / 4, h = g.lanes_width / 20}
	
local function get_raise()
	raise = 0
	if ribbon.y + ribbon.h >= 1080 then
		raise = -ribbon.h
	else
		raise = ribbon.h
	end
	return raise
end

	
	parts.source = {
		{id = "src-ribbons", path = "customize/extension/Ribbons/parts.png"}
	}
	
	parts.image = {
	-- blank
		{id = "ribbon_blank", 		src = "src-ribbons", x = 800, y = 360, w = 200, h = 40},
	-- randoms
		{id = "ribbon_random_1",	src = "src-ribbons", x = 0, y = 0, w = 200, h = 40},
		{id = "ribbon_random_2",	src = "src-ribbons", x = 0, y = 40, w = 200, h = 40},
		{id = "ribbon_random_3",	src = "src-ribbons", x = 0, y = 80, w = 200, h = 40},
		{id = "ribbon_random_4",	src = "src-ribbons", x = 0, y = 120, w = 200, h = 40},
		{id = "ribbon_random_5",	src = "src-ribbons", x = 0, y = 160, w = 200, h = 40},
		{id = "ribbon_random_6",	src = "src-ribbons", x = 0, y = 200, w = 200, h = 40},
		{id = "ribbon_random_7",	src = "src-ribbons", x = 0, y = 240, w = 200, h = 40},
		{id = "ribbon_random_8",	src = "src-ribbons", x = 0, y = 280, w = 200, h = 40},
		{id = "ribbon_random_9",	src = "src-ribbons", x = 0, y = 320, w = 200, h = 40},
		{id = "ribbon_random_a",	src = "src-ribbons", x = 0, y = 360, w = 200, h = 40},
	-- gauges
		{id = "ribbon_gauge_1",		src = "src-ribbons", x = 200, y = 0, w = 200, h = 40},
		{id = "ribbon_gauge_2",		src = "src-ribbons", x = 200, y = 40, w = 200, h = 40},
		{id = "ribbon_gauge_3",		src = "src-ribbons", x = 200, y = 80, w = 200, h = 40},
		{id = "ribbon_gauge_4",		src = "src-ribbons", x = 200, y = 120, w = 200, h = 40},
		{id = "ribbon_gauge_5",		src = "src-ribbons", x = 200, y = 160, w = 200, h = 40},
		{id = "ribbon_gauge_6",		src = "src-ribbons", x = 200, y = 200, w = 200, h = 40},
	-- difficulties
		{id = "ribbon_diff_0",		src = "src-ribbons", x = 400, y = 200, w = 200, h = 40},
		{id = "ribbon_diff_1",		src = "src-ribbons", x = 400, y = 0, w = 200, h = 40},
		{id = "ribbon_diff_2",		src = "src-ribbons", x = 400, y = 40, w = 200, h = 40},
		{id = "ribbon_diff_3",		src = "src-ribbons", x = 400, y = 80, w = 200, h = 40},
		{id = "ribbon_diff_4",		src = "src-ribbons", x = 400, y = 120, w = 200, h = 40},
		{id = "ribbon_diff_5",		src = "src-ribbons", x = 400, y = 160, w = 200, h = 40},
	-- LN modes
		{id = "ribbon_ln_1",		src = "src-ribbons", x = 600, y = 0, w = 200, h = 40},
		{id = "ribbon_ln_2",		src = "src-ribbons", x = 600, y = 40, w = 200, h = 40},
		{id = "ribbon_ln_3",		src = "src-ribbons", x = 600, y = 80, w = 200, h = 40},
	-- play mods
		{id = "ribbon_play_1",		src = "src-ribbons", x = 800, y = 0, w = 200, h = 40},
		{id = "ribbon_play_2",		src = "src-ribbons", x = 800, y = 40, w = 200, h = 40},
		{id = "ribbon_play_3",		src = "src-ribbons", x = 800, y = 80, w = 200, h = 40},
	-- GAS
		{id = "ribbon_gas_1", 		src = "src-ribbons", x = 200, y = 240, w = 200, h = 40},
	-- course/dan
		{id = "ribbon_course_1",	src = "src-ribbons", x = 1200, y = 0, w = 200, h = 40},
		{id = "ribbon_course_2",	src = "src-ribbons", x = 1200, y = 40, w = 200, h = 40},
	-- course stages
		{id = "ribbon_stage_1", 	src = "src-ribbons", x = 1000, y = 0, w = 200, h = 40},
		{id = "ribbon_stage_2", 	src = "src-ribbons", x = 1000, y = 40, w = 200, h = 40},
		{id = "ribbon_stage_3", 	src = "src-ribbons", x = 1000, y = 80, w = 200, h = 40},
		{id = "ribbon_stage_4", 	src = "src-ribbons", x = 1000, y = 120, w = 200, h = 40},
		{id = "ribbon_stage_5", 	src = "src-ribbons", x = 1000, y = 160, w = 200, h = 40},
		{id = "ribbon_stage_6", 	src = "src-ribbons", x = 1000, y = 200, w = 200, h = 40},
		{id = "ribbon_stage_7", 	src = "src-ribbons", x = 1000, y = 240, w = 200, h = 40},
		{id = "ribbon_stage_8", 	src = "src-ribbons", x = 1000, y = 280, w = 200, h = 40},
		{id = "ribbon_stage_9", 	src = "src-ribbons", x = 1000, y = 320, w = 200, h = 40},
		{id = "ribbon_stage_10", 	src = "src-ribbons", x = 1000, y = 360, w = 200, h = 40}
	}
	
	parts.imageset = {
		{id = "ribbon_random", ref = 42, images = {
			"ribbon_random_1","ribbon_random_2","ribbon_random_3","ribbon_random_4","ribbon_random_5",
			"ribbon_random_6","ribbon_random_7","ribbon_random_8","ribbon_random_9","ribbon_random_a"
		}, act = 42},
		{id = "ribbon_gauge", ref = 40, images = {
			"ribbon_gauge_1","ribbon_gauge_2","ribbon_gauge_3","ribbon_gauge_4","ribbon_gauge_5","ribbon_gauge_6"
		}, act = 40},
		{id = "ribbon_ln", ref = 308, images = {
			"ribbon_ln_1","ribbon_ln_2","ribbon_ln_3"
		}, act = 308},
		{id = "ribbon_gas", ref = 78, images = {
			"ribbon_blank","ribbon_gas_1","ribbon_gas_1","ribbon_gas_1","ribbon_gas_1"
		}, act = 78}
	}
	
	parts.destination = {
	-- everything button-able
		{id = "ribbon_random",				dst = {{x = ribbon.x, y = ribbon.y, w = ribbon.w, h = ribbon.h}}},
		{id = "ribbon_gauge", 				dst = {{x = ribbon.x + ribbon.w, y = ribbon.y, w = ribbon.w, h = ribbon.h}}},
		{id = "ribbon_ln", 	op = {173}, 	dst = {{x = ribbon.x, y = ribbon.y + get_raise(), w = ribbon.w, h = ribbon.h}}},
	-- GAS draws over gauge
		{id = "ribbon_gas",					dst = {{x = ribbon.x + ribbon.w, y = ribbon.y, w = ribbon.w, h = ribbon.h}}},
	-- difficulties
		{id = "ribbon_diff_".. get_diff(),  dst = {{x = ribbon.x + ribbon.w * 2, y = ribbon.y, w = ribbon.w, h = ribbon.h}}},
	-- autoplay and replay
		{id = "ribbon_".. get_play(),  		dst = {{x = ribbon.x + ribbon.w * 3, y = ribbon.y, w = ribbon.w, h = ribbon.h}}},
	-- stage (i couldn't get this to work)
	--	{id = "ribbon_stage_".. get_stage(),	dst = {{x = ribbon.x + ribbon.w * 2, y = ribbon.y + get_raise(), w = ribbon.w, h = ribbon.h}}},
	}
	
	return parts	
	
end

return {
	parts = parts,
	load = load
}