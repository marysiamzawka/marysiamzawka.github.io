local parts = {}

local skinName = "LR2 motion.tga"

-- @param t geometry
local function load(t)	
	parts.source = {
		{id = "src-fceffect",	path = "customize/fullcombo/lr2/"..skinName},
	}
	parts.image = {
		{id = "fc-effect", src = "src-fceffect", x = 0, y = 0, w = 1950, h = 966, divx = 10, divy = 3, cycle = 1000, timer = 48, filter = 1},
	}
	parts.destination = {
		{id = "fc-effect", loop = -1, timer = 48, stretch = 3, blend = 2, dst = {
			{time = 0, x = t.lane_origin_x, y = t.lane_origin_y, w = t.lanes_width, h = t.lane_height, a = 255, filter = 1},
			{time = 1000, a = 255}
		}},
	}			
	return parts	
end

return {
	parts = parts,
	load = load
}