-- Info over BGA extension for simple-play
-- by Mr. Mary

-- fonts from m+ set
-- inspired by Hex's LR2 skin

-- you are welcome to download and share
-- (your PC will not be shattered the moment you try to redistribute)

local parts = {}

-- param g : geometry
local function load(g)

	local bga_ratio = g.bga_width / 1050

	local bga_title_y = g.bga_y + g.bga_height / 2 - 32 * bga_ratio
	local bga_artist_y = g.bga_y + g.bga_height / 2 - 128 * bga_ratio
	local bga_subtitle_y = g.bga_y + g.bga_height / 2 - 60 * bga_ratio
	local bga_table_y = g.bga_y + g.bga_height / 2 - 250 * bga_ratio
	local bga_genre_y = g.bga_y + g.bga_height / 2 + 120 * bga_ratio
	local bga_center = g.bga_x + g.bga_width / 2

	local function check_nil(txt)
		ret = ""
		if txt ~= nil
		then 
			ret = txt .. " "
		end
		return ret
	end

	local furu_title = main_state.text(10)
	local zanra = main_state.text(13)

	local extract1 = furu_title:gsub('%([^)]*%)', "")
	local extract2 = extract1:gsub('%[[^)]*%]', "")
	local extract3 = extract2:gsub('%-[^)]*%-', "")
	local extract4 = extract3:gsub('%<[^)]*%>', "")
	local extract_title = extract4:gsub('%（[^)]*%）', "")

	local extract_sub1 = furu_title:match('%([^)]*%)')
	local extract_sub2 = furu_title:match('%[[^)]*%]')
	local extract_sub3 = furu_title:match('%（[^)]*%）')
	local extract_sub4 = furu_title:match('%-[^)]*%-')
	local extract_sub5 = furu_title:match('%<[^)]*%>')

	local extract_gen1 = zanra:match('%([^)]*%)')
	local extract_gen2 = zanra:match('%[[^)]*%]')
	local extract_gen3 = zanra:match('%（[^)]*%）')
	local extract_gen4 = zanra:match('%-[^)]*%-')

	local extract_titlesub = check_nil(extract_sub1) .. check_nil(extract_sub3) .. check_nil(extract_sub4) .. check_nil(extract_sub5) .. check_nil(extract_sub2)
	local extract_genresub = check_nil(extract_gen1) .. check_nil(extract_gen2) .. check_nil(extract_gen3) .. check_nil(extract_gen4)
	local extract_subtitle = extract_titlesub .. extract_genresub ..  check_nil(main_state.text(11))

	local ex_zan1 = zanra:gsub('%([^)]*%)', "")
	local ex_zan2 = ex_zan1:gsub('%[[^)]*%]', "")
	local ex_zan3 = ex_zan2:gsub('%-[^)]*%-', "")
	local extract_genre = ex_zan3:gsub('%（[^)]*%）', "")



	parts.source = {
		{id = "bga-src-judgerank",	path = "parts/judgerank.png"},
	}
	parts.image = {
		{id = "bga-judge-veryeasy",	src = "bga-src-judgerank", x = 0, y = 0, w = 204, h = 24},
		{id = "bga-judge-easy",		src = "bga-src-judgerank", x = 0, y = 24, w = 204, h = 24},
		{id = "bga-judge-normal",	src = "bga-src-judgerank", x = 0, y = 48, w = 204, h = 24},
		{id = "bga-judge-hard",		src = "bga-src-judgerank", x = 0, y = 72, w = 204, h = 24},
		{id = "bga-judge-veryhard",	src = "bga-src-judgerank", x = 0, y = 96, w = 204, h = 24},
	}
	parts.font = {
		{id = "black", path = "customize/extension/InfoOverBGA/mgenplus-1c-black.ttf"},
		{id = "bold", path = "customize/extension/InfoOverBGA/mgenplus-1c-bold.ttf"},
		{id = "light", path = "customize/extension/InfoOverBGA/mgenplus-1c-medium.ttf"},
	}

	parts.text = {
		{id = "bga-music-title", filter = 1, font = "black", size = 72 * bga_ratio, constantText = extract_title, overflow = 1, align = 1},
		{id = "bga-music-genre",	font = "light", size = 24 * bga_ratio, constantText = extract_genre, overflow = 1, align = 1},
		{id = "bga-music-subtitle",	font = "light", size = 32 * bga_ratio, constantText = extract_subtitle, overflow = 1, align = 1},
		{id = "bga-music-artist",	font = "light", size = 24 * bga_ratio, ref = 16, overflow = 1, align = 1},
		{id = "bga-table",			font = "bold", size = 16 * bga_ratio, ref = 1003, overflow = 1, align = 1},
		{id = "bga-table-level", 	font = "black", size = 400 * bga_ratio, ref = 1002, overflow = 1, align = 1}
	}

	parts.destination = {
		{id = -110, dst = {
			{time = 0, x = g.bga_x, y = g.bga_y, w = g.bga_width, h = g.bga_height, a = 192}
		}},
		{id = "bga-table-level", loop = 0, dst = {
			{time = 0, x = bga_center, y = bga_table_y, w = g.bga_width, h = 400 * bga_ratio, a = 31},
			{time = 2000, a = 63},
			{time = 4000, a = 31}
		}},


		{id = "bga-music-title", dst = {
			{time = 0, x = bga_center, y = bga_title_y, w = g.bga_width, h = 72 * bga_ratio, a = 255}
		}},
		{id = "bga-music-subtitle", dst = {
			{time = 0, x = bga_center, y = bga_subtitle_y, w = g.bga_width, h = 32 * bga_ratio, a = 255}
		}},
		{id = "bga-music-genre", dst = {
			{time = 0, x = bga_center, y = bga_genre_y, w = g.bga_width, h = 24 * bga_ratio, a = 255}
		}},
		{id = "bga-music-artist", dst = {
			{time = 0, x = bga_center, y = bga_artist_y, w = g.bga_width, h = 24 * bga_ratio, a = 255}
		}},

		{id = "bga-judge-veryeasy", op = {184}, dst = {
			{time = 0, x = g.bga_x + g.bga_width - 210, y = g.bga_y + 6, w = 204, h = 24}
		}},
		{id = "bga-judge-easy", op = {183}, dst = {
			{time = 0, x = g.bga_x + g.bga_width - 210, y = g.bga_y + 6, w = 204, h = 24}
		}},
		{id = "bga-judge-normal", op = {182}, dst = {
			{time = 0, x = g.bga_x + g.bga_width - 210, y = g.bga_y + 6, w = 204, h = 24}
		}},
		{id = "bga-judge-hard", op = {181}, dst = {
			{time = 0, x = g.bga_x + g.bga_width - 210, y = g.bga_y + 6, w = 204, h = 24}
		}},
		{id = "bga-judge-veryhard", op = {180}, dst = {
			{time = 0, x = g.bga_x + g.bga_width - 210, y = g.bga_y + 6, w = 204, h = 24}
		}},

	}

	return parts	
end

return {
	parts = parts,
	load = load
}